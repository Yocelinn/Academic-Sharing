<template>
    <div class="back">
        
    </div>
</template>

<script>

</script>

<style scoped>
.back{
    position: relative;
    width: 100%;
    height: 100%;
    background-color: #4a7c59;
}

</style>